# portfolio-brief

A ZeroClaw tool plugin to fetch a Solana wallet's token balances and shape them into a concise portfolio brief for an LLM (~200 tokens).

## Custody Tier & Threat Model
**Tier: T0 (Read-only)**

This plugin is strictly read-only. It fetches token balances from a Solana RPC and formats them. 
- **Secrets held**: None. (It may hold an RPC URL with an API key if configured, but no private keys are ever held).
- **Threat Model**: The primary threat is a malicious user injecting a prompt to try and exfiltrate the RPC key or trick the agent into sending funds. Because this plugin *does not have access to any keys or signing capabilities*, prompt injection cannot result in lost funds. The plugin is strictly bounded to the `config_read` and `http_client` permissions.

## Configuration Keys
In your agent's configuration for this plugin, you can specify:
- `rpc_url`: The Solana RPC URL to use. Defaults to `https://api.mainnet-beta.solana.com`.

## What it does
1. Takes a Solana `wallet` address as an argument.
2. Calls `getTokenAccountsByOwner` on the configured RPC URL.
3. Filters for tokens with a positive balance.
4. Returns a condensed text block showing the Mint address and Balance.

## Worked Example
An agent receives a message: "What's my portfolio looking like? Address: 7xK..."
The LLM calls `portfolio-brief` with `{"wallet": "7xK..."}`.
The plugin queries the RPC and returns:
```text
Portfolio Brief:
- Mint: EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v | Balance: 25.5
- Mint: So11111111111111111111111111111111111111112 | Balance: 1.2
```
The LLM then shapes this into a natural language response.

## What to build next
Next, we can build a `portfolio-worth` plugin which combines token balances with Jupiter API price lookups to return the total USD value of the portfolio. Due to `wasi:http`, we can chain these lookups in the pure core without needing heavy async dependencies.

## What fought us on `wasm32-wasip2`
Using the standard `solana-client` crate was immediately discarded as it pulls in Tokio and async runtimes that do not compile well or run smoothly inside `wasm32-wasip2` without significant hacking. Instead, we adopted the strategy used by the core channel plugins:
1. Build a pure Rust core (`src/core.rs`) that handles JSON construction and parsing using `serde_json`. This is fully testable on the host via `cargo test`.
2. Use the blocking `waki` HTTP client exclusively in the WASM shim (`src/lib.rs`). This keeps the component minimal and avoids async pollution, fitting perfectly into the ZeroClaw `wasi:http` sandbox.

## License
MIT
