use std::collections::HashMap;
use serde::Deserialize;
use serde_json::Value;

#[derive(Deserialize, Default, Clone)]
pub struct PortfolioConfig {
    #[serde(default)]
    pub rpc_url: String,
}

impl PortfolioConfig {
    pub fn from_section(map: &HashMap<String, String>) -> Self {
        let mut cfg = Self::default();
        if let Some(val) = map.get("rpc_url") {
            cfg.rpc_url = val.clone();
        }
        cfg
    }
}

pub fn build_rpc_request(wallet: &str) -> Value {
    serde_json::json!({
        "jsonrpc": "2.0",
        "id": 1,
        "method": "getTokenAccountsByOwner",
        "params": [
            wallet,
            {
                "programId": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
                "encoding": "jsonParsed"
            }
        ]
    })
}

pub fn parse_rpc_response(response: &Value) -> Result<String, String> {
    let mut out = String::new();
    out.push_str("Portfolio Brief:\n");
    let result = response.get("result").and_then(|r| r.get("value")).and_then(|v| v.as_array());
    let mut count = 0;
    if let Some(accounts) = result {
        for acc in accounts {
            let parsed = acc.get("account").and_then(|a| a.get("data")).and_then(|d| d.get("parsed")).and_then(|p| p.get("info"));
            if let Some(info) = parsed {
                let mint = info.get("mint").and_then(|m| m.as_str()).unwrap_or("Unknown");
                let amount_f64 = info.get("tokenAmount").and_then(|t| t.get("uiAmount")).and_then(|u| u.as_f64()).unwrap_or(0.0);
                if amount_f64 > 0.0 {
                    out.push_str(&format!("- Mint: {} | Balance: {}\n", mint, amount_f64));
                    count += 1;
                }
            }
        }
        if count == 0 {
            out.push_str("No tokens found with positive balance.");
        }
    } else {
        out.push_str("No tokens found or error parsing response.");
    }
    
    // Trim output if it's too long
    if out.len() > 1000 {
        out.truncate(1000);
        out.push_str("...");
    }
    Ok(out)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_rpc_response_empty() {
        let resp = serde_json::json!({
            "result": {
                "value": []
            }
        });
        let out = parse_rpc_response(&resp).unwrap();
        assert!(out.contains("No tokens found with positive balance."));
    }
}
