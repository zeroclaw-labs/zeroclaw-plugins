//! A ZeroClaw WIT tool plugin: `portfolio-brief`.
//!
//! Fetches a Solana wallet's token balances and formats a concise portfolio brief.

pub mod core;

#[cfg(target_family = "wasm")]
mod component {
    wit_bindgen::generate!({
        path: "../../wit/v0",
        world: "tool-plugin",
        features: ["plugins-wit-v0"],
    });

    use std::collections::HashMap;

    use crate::core::{build_rpc_request, parse_rpc_response, PortfolioConfig};
    use exports::zeroclaw::plugin::plugin_info::Guest as PluginInfo;
    use exports::zeroclaw::plugin::tool::{Guest as Tool, ToolResult};
    use zeroclaw::plugin::logging::{
        log_record, LogLevel, PluginAction, PluginEvent, PluginOutcome,
    };

    struct PortfolioBrief;

    const PLUGIN_NAME: &str = "portfolio-brief";
    const PLUGIN_VERSION: &str = env!("CARGO_PKG_VERSION");
    const TOOL_NAME: &str = "portfolio-brief";

    #[derive(serde::Deserialize)]
    struct ExecuteArgs {
        wallet: String,
        #[serde(rename = "__config", default)]
        config: HashMap<String, String>,
    }

    impl PluginInfo for PortfolioBrief {
        fn plugin_name() -> String {
            PLUGIN_NAME.to_string()
        }

        fn plugin_version() -> String {
            PLUGIN_VERSION.to_string()
        }
    }

    impl Tool for PortfolioBrief {
        fn name() -> String {
            TOOL_NAME.to_string()
        }

        fn description() -> String {
            "Token balances for a Solana wallet, shaped into a concise text brief. Operates at custody tier T0 (Read-only).".to_string()
        }

        fn parameters_schema() -> String {
            serde_json::json!({
                "type": "object",
                "properties": {
                    "wallet": {
                        "type": "string",
                        "description": "The Solana wallet address to get the portfolio for."
                    }
                },
                "required": ["wallet"]
            })
            .to_string()
        }

        fn execute(args: String) -> Result<ToolResult, String> {
            let parsed: ExecuteArgs = match serde_json::from_str(&args) {
                Ok(a) => a,
                Err(e) => {
                    emit(
                        PluginAction::Fail,
                        PluginOutcome::Failure,
                        "invalid arguments",
                    );
                    return Ok(ToolResult {
                        success: false,
                        output: String::new(),
                        error: Some(format!("invalid arguments: {e}")),
                    });
                }
            };

            let cfg = PortfolioConfig::from_section(&parsed.config);
            let rpc_url = if cfg.rpc_url.is_empty() {
                "https://api.mainnet-beta.solana.com"
            } else {
                &cfg.rpc_url
            };

            let req_body = build_rpc_request(&parsed.wallet);
            let resp = match waki::Client::new().post(rpc_url).json(&req_body).send() {
                Ok(res) => {
                    match res.json::<serde_json::Value>() {
                        Ok(v) => v,
                        Err(e) => {
                            emit(
                                PluginAction::Fail,
                                PluginOutcome::Failure,
                                &format!("failed to parse RPC response: {}", e),
                            );
                            return Ok(ToolResult {
                                success: false,
                                output: String::new(),
                                error: Some(format!("RPC JSON parse error: {}", e)),
                            });
                        }
                    }
                },
                Err(e) => {
                    emit(
                        PluginAction::Fail,
                        PluginOutcome::Failure,
                        &format!("failed HTTP request: {}", e),
                    );
                    return Ok(ToolResult {
                        success: false,
                        output: String::new(),
                        error: Some(format!("HTTP error: {}", e)),
                    });
                }
            };

            match parse_rpc_response(&resp) {
                Ok(output) => {
                    emit(
                        PluginAction::Complete,
                        PluginOutcome::Success,
                        "portfolio retrieved",
                    );
                    Ok(ToolResult {
                        success: true,
                        output,
                        error: None,
                    })
                }
                Err(err) => {
                    emit(
                        PluginAction::Fail,
                        PluginOutcome::Failure,
                        &format!("failed to fetch portfolio: {}", err),
                    );
                    Ok(ToolResult {
                        success: false,
                        output: String::new(),
                        error: Some(format!("failed to fetch portfolio: {}", err)),
                    })
                }
            }
        }
    }

    fn emit(
        action: PluginAction,
        outcome: PluginOutcome,
        message: &str,
    ) {
        log_record(
            LogLevel::Info,
            &PluginEvent {
                function_name: "portfolio_brief::tool::execute".to_string(),
                action,
                outcome: Some(outcome),
                duration_ms: None,
                attrs: None,
                message: message.to_string(),
            },
        );
    }

    export!(PortfolioBrief);
}
